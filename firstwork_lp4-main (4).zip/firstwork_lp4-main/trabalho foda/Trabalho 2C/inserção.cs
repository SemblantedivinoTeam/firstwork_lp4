﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho_2C
{
    internal class inserção
    {
        public string enunciado;
        public string altA;
        public string altB;
        public string altC;
        public string altD;
        public string altE;
        public bool Resultado;
        public string ResoluçãoFinal;

    }
}
